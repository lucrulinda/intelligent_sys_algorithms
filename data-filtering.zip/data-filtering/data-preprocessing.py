import pandas as pd 
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer


stop_words = stopwords.words('english')
twitter_dataset = pd.read_csv("C:/Users/rulij/Downloads/archive/hashtag_joebiden.csv")

# Translating emojis's meanings
emojis = {':)': 'smile', ':-)': 'smile', ';d':'wink', ':-E': 'vampire', ':(': 'sad',
':-(': 'sad', ':-<': 'sad', ':P': 'raspberry', ':O': 'surprised', ':-@': 'shocked', ':@': 'shocked',
':-$': 'confused', '$_$':'greedy', '@@': 'eyeroll', ':-!':"confused", ':-D': 'smile', ':-0': 'yell',
'O.o': 'confused', '<(-_-)>': 'robot', 'd[-_-]b': 'dj', ":'-": 'sadsmile', ';)': 'wink', ';-)': 'wink',
'O:-)':'angel', 'o*-):':'angel', '(:-D': 'gossip', '=^.^=': 'cat'}

def clean_data(data):
    data = str(data).lower()
    data = re.sub(r"@\S+ ", r'', data)
    for emoji in emojis.keys():
        data = data.replace(emoji,emojis[emoji])
    data = re.sub("\s+", ' ', data)
    data = re.sub("\n", ' ', data)
    letters = re.sub("[^a-zA-Z]", " ", data)

    return letters

def stop_words(words):
    filter_words = []
    for w in words: 
        if w not in stop_words:
            filter_words.append(w)
    return filter_words

#clean the data
twitter_dataset['text'] = twitter_dataset['text'].apply(lambda x: clean_data(x))
#splitting text into lists:
twitter_dataset['text'] = twitter_dataset['text'].apply(lambda x: x.split(" "))
#removing stop words:
twitter_dataset['text'] = twitter_dataset['text'].apply(lambda x: x.stop_words(x))

# stemming
lemmatizer = WordNetLemmatizer()
twitter_dataset['text'] = twitter_dataset['text'].apply(lambda x: [lemmatizer.lemmatize(word) for word in x])
# joining the list back to text
twitter_dataset['text'] = twitter_dataset['text'].apply(lambda x: ' '.join(x))
